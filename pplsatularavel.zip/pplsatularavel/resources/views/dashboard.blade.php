@extends('layouts/app')
@section('content')
<div class="row">
<h3>Selamat Datang</h3>
                        <!-- Earnings (Monthly) Card Example -->
</div>

                    <!-- Content Row -->

 <div class="row">

                        <!-- Area Chart -->
 
 </div>

                    <!-- Content Row -->
<div class="row">

                        <!-- Content Column -->
  
</div>
@endsection