<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class dataclub extends Controller
{
    //
}
